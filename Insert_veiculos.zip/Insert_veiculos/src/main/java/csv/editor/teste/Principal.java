package csv.editor.teste;
import java.io.IOException;
import java.sql.SQLException;


public class Principal {

	public static void main(String[] args) throws IOException, SQLException {

		//CSVReader csvReader = CSV.buscarArquivoCSV();
		CSV.printRapidoCSV();

	}
	

}
